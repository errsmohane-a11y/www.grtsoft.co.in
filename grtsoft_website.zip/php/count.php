<?php
$file = $_GET['file'];
$path = '../downloads/'.$file;
$count_file = '../downloads/counter.txt';
$count = file_exists($count_file)?file_get_contents($count_file):0;
$count++;
file_put_contents($count_file,$count);
header('Location: '.$path);
exit;
?>