GRTSoft Website

Upload all files to your server.
Place your software files in /downloads/
Access pages via index.html etc.